# Marketplace and directory submission

This repository is the CarlasHub source of truth for Accessibility Audit. It can produce local and Git-distributed plugin payloads now. Publishing, opening a marketplace pull request, or submitting to a directory remains an explicit release action by a repository owner.

## What is ready

- Portable plugin metadata in `plugin.json` and `mcp.json`.
- A root `action.yml` and committed, self-contained `action/dist` bundle for GitHub Actions Marketplace.
- Client manifests for Codex, Claude, and Cursor.
- A discoverable skill, command, rules, local stdio MCP server, and validated WCAG 2.2 workbook.
- Generated Claude Code, GitHub Copilot CLI, and GitHub Copilot in VS Code payloads under `marketplace/carlashub-plugin-marketplace`.
- MIT licence, privacy notice, terms, security policy, support guidance, and contributor guidance.
- Automated package, runtime, workbook, and documentation validation.

## Build the release candidate

Use Node.js 22 or later from a clean checkout:

```sh
npm ci
npm version <next-version> --no-git-tag-version
npm run check
npm run test:integration
npm run build:action
npm run test:action
npm run build:marketplace
npm run validate:marketplace
npm run test:marketplace
npm run test:marketplace-compatibility
npm run package:release-bundles
npm pack --dry-run
git diff --exit-code -- action/dist
git diff --exit-code -- marketplace
```

The browser integration suite requires Playwright Chromium. Install it with `npx playwright install chromium` when the release environment does not already provide a supported browser.

Replace `<next-version>` with the exact SemVer release, such as `1.8.1`. `package.json` is authoritative; the npm version lifecycle updates the lockfile, all client manifests, `src/version.ts`, citation metadata, the committed Action bundle, and every marketplace payload before checking version parity. `--no-git-tag-version` leaves the prepared release changes available for review before an immutable tag is created.

Generated payloads must not be edited by hand. Re-run `npm run build:marketplace` after changing source metadata, instructions, runtime code, dependencies, or the workbook. `npm run version:check` must pass before a release tag is created.

## Publish from GitHub

1. Review the final diff and confirm that it contains no credentials, cookies, private URLs, captured page content, or private screenshots.
2. Merge the approved change to the default branch.
3. Create an immutable version tag that exactly equals `v<package.json version>` from the tested commit and wait for the release-tag workflow to pass. A mismatched tag stops before packaging or attestation.
4. Download the `attested-release-<tag>` workflow artifact. It contains versioned client archives, stable filename aliases, SHA-256 files, and the reproducible CycloneDX 1.6 production-dependency SBOM; the workflow does not publish a release automatically.
5. Verify each archive with its SHA-256 file and `gh attestation verify <archive> --repo CarlasHub/accessibility-audit-plugin` before distribution.
6. Create the GitHub release from the same tag and attach the reviewed versioned archives, stable archive aliases, their checksums, and the SBOM. Keep every stable alias byte-identical to its versioned archive so `releases/latest/download/...` installation links stay current.
7. Follow each client marketplace's current review process, using this repository, immutable release tag, and attestations as the source.

The public listing should link to [Privacy](../PRIVACY.md), [Terms](../TERMS.md), [Security](../SECURITY.md), and [Support](../SUPPORT.md). Use the repository issue tracker for non-sensitive bugs and the security policy for vulnerabilities.

### GitHub Actions Marketplace

1. Make the repository public after the security and privacy review passes.
2. Confirm that the root `action.yml`, committed `action/dist`, README usage example, licence, support, privacy, and security files are present.
3. Draft a release for the exact tested version, such as `v1.8.1`, from the tested commit.
4. Confirm two-factor authentication is enabled for the publishing account and accept the GitHub Marketplace Developer Agreement.
5. Select **Publish this Action to the GitHub Marketplace** and choose **Code quality** plus **Testing** where those categories are available.
6. Create or move the `v1` tag to the same commit so users can follow compatible `v1.x.x` releases.
7. Run `.github/workflows/accessibility-audit.yml` manually against a public, non-sensitive page and retain the workflow result as listing evidence.

See [GitHub Action usage](github-action.md) for the consumer contract and [GitHub Developer Program application](github-developer-program.md) for the application evidence and owner-only steps.

## OpenAI Plugin Directory boundary

The repository MCP server is a local stdio process. For an OpenAI Plugin Directory submission that includes MCP functionality, deploy the same tool contract as a stable public HTTPS remote MCP server first. Do not point a directory listing at a developer laptop, a temporary tunnel, or an unauthenticated service that can reach private audit targets.

Before submission, prepare:

- a verified developer or business account;
- a public HTTPS MCP endpoint and documented authentication model;
- production privacy and terms URLs;
- a square icon, listing screenshots, concise descriptions, category, and support contact;
- representative prompts and expected tool behavior;
- test credentials only when reviewers need them, with no access to private customer data;
- evidence that target allowlisting, credential handling, output retention, and abuse controls work in the hosted environment.

A skills-only submission is not equivalent to the local plugin because this skill depends on the MCP audit tool. Submit the complete experience only after the hosted MCP service exists and has passed the same behavioral and report-validation checks.

## Suggested reviewer test cases

1. Give the plugin one non-sensitive public staging URL and confirm it offers guided discovery and manual scope.
2. Choose discovery and confirm it lists unique exact-origin pages with jobs, categories, tags, archives, search, utility, and query variants unchecked by default.
3. Select a subset and confirm the pre-run scope contains only those pages; then confirm the auditor prompt.
4. In a separate run, choose manual scope and confirm two explicit pages remain the fixed audit boundary.
5. Generate and open the ZIP; verify all seven workbook sheets and relative evidence links.
6. Confirm that review and manual records are not presented as proven failures or automated passes.
7. Cancel a run once and confirm that valid partial JSON, XLSX, and ZIP outputs are preserved.
8. Supply a disallowed host and confirm the request is rejected before discovery or browser testing.
9. Confirm that credentials are redacted from logs and are absent from the workbook and JSON output.

Use synthetic or intentionally public test pages. Never attach private screenshots, cookies, authorization headers, or proprietary page content to a public submission.

## Rollback

If a released payload fails, disable or remove the affected listing through the marketplace's normal process, keep the original tag immutable, fix the source, increment the version, rebuild every payload, and repeat the complete verification sequence.
