# Accessibility Audit Plugin

An isolated Codex, Claude Code, Cursor, GitHub Copilot CLI, and GitHub Copilot in VS Code plugin that helps teams find and document web accessibility barriers. Give it one or more page URLs—or a file containing URLs—and it runs repeatable checks in a headless browser, then produces an Excel report, detailed JSON evidence, and a portable ZIP.

You do not need to know WCAG terminology to run the plugin. Start with the workflow below, use the [installation guide](docs/installation.md) for your client, then use the [plain-language user guide](docs/user-guide.md) and [WCAG basics](docs/wcag-basics.md) to understand the results.

> **Important:** this plugin is an automated testing aid, not a WCAG certification. A report with no automated findings does not prove that a page is accessible. Screen-reader, physical-device, content-meaning, visual-judgment, and other guided checks remain manual. W3C likewise states that no evaluation tool alone can determine whether a site meets accessibility standards.

## Start here

If the plugin is already installed:

1. Decide which pages are in scope. The plugin tests only the URLs you supply; it does not discover or crawl a whole site.
2. In Cursor or Claude Code, run `/accessibility-audit` with one URL, several URLs, or a page-list file. In Codex or Copilot, ask it to use the Accessibility Audit plugin with the same input.
3. Check the confirmation form. It shows the input, the auditor name, and the landing-page QA URL before testing starts.
4. Let the headless audit finish, or stop it safely if needed. Progress appears in the editor or terminal.
5. Extract the generated ZIP and open `Accessibility_Audit_Report.xlsx`. Keep the workbook and `screenshots` folder together so its evidence links continue to work.

One page:

```text
/accessibility-audit https://preview.example.test/
```

Selected pages:

```text
/accessibility-audit https://preview.example.test/ https://preview.example.test/jobs https://preview.example.test/contact
```

Every page in a prepared list:

```text
/accessibility-audit pages.xlsx
```

Equivalent request in Codex or Copilot:

```text
Use the Accessibility Audit plugin to audit every URL in pages.xlsx.
```

For a complete-site audit, the page-list file must contain the complete canonical URL inventory. Supplying the home page does **not** make the plugin crawl the rest of the site.

### What the confirmation fields mean

| Field | Plain-language meaning | Default |
|---|---|---|
| Pages/input | The exact URLs or page-list file that will be tested. | Required |
| Auditor | The name recorded in the workbook. Use a person’s name when a person owns the audit. | `Automated` |
| Landing-page QA URL | The project’s main QA or staging URL shown in the Overview sheet. It is report metadata and does not add pages to the scope. | First resolved URL |
| Output directory | The isolated folder that receives the report, JSON, screenshots, and ZIP. | `Accessibility Audit Results` in the user’s home directory |

### What happens during the audit

Every supplied page is checked at desktop (1440×1000), mobile (390×844), and 320-pixel reflow sizes. In plain terms, the plugin looks for problems such as:

- images, links, buttons, and form fields that do not have usable names;
- incorrect page structure or broken relationships between controls and content;
- keyboard focus that is unreachable, out of order, invisible, or fully covered;
- menus, disclosures, and tabs whose state or keyboard operation is broken;
- content that overflows at narrow widths or after WCAG text-spacing overrides;
- same-site links that are empty, placeholders, missing fragments, or consistently return 404/410;
- selected target-size, table, media, and responsive-layout signals that require review.

The browser runs headlessly by default, so it should not take over the desktop. Visible consent banners are dismissed before the main checks and evidence capture. Confirmed component failures receive a focused screenshot when the element can be located reliably.

### How to interpret the result

The report separates four evidence categories:

| Category | Meaning | What to do |
|---|---|---|
| `confirmed` | The plugin reproduced deterministic evidence of a failure. | Fix it, then retest. A person should still confirm high-impact or context-sensitive cases. |
| `review` | The plugin found a credible signal, but context or a WCAG exception requires human judgment. | Perform the procedure in the Testing column before deciding whether it fails. |
| `blocker` | The page could not be tested, for example because it returned an unavailable response. | Restore access or correct the URL, then rerun it. Never count it as a pass. |
| `manual` | Automation cannot determine the result. | Complete the stated guided check with an appropriate tester. |

Every populated workbook row starts with `Status = Fail` because that is the implementation-workflow default requested by the report template. It does not convert a `review` signal into a confirmed WCAG failure. Use the Labels and ProductNote fields to identify the evidence category, and read Testing before triage.

Severity (`Critical`, `Serious`, `Moderate`, or `Minor`) describes expected user impact. It is different from WCAG level, evidence confidence, remediation effort, and delivery priority.

See [Understanding the report](docs/reporting.md) for a worksheet and column guide, and [Manual verification](docs/manual-verification.md) for checks that remain outstanding.

## Features

- Headless Playwright Chromium execution with visible terminal or MCP progress.
- Automatic one-time installation of headless Playwright Chromium when no supported browser is available; runtime and browser files stay in plugin-owned storage.
- axe-core WCAG 2.2 A/AA rules plus selected best-practice signals, which remain review items when no WCAG success criterion is mapped.
- DOM and semantic checks for page structure, image alternatives, controls, fields, landmarks, duplicate ids, tables, and media.
- Sequential keyboard traversal, focus visibility review, focus obscuration checks, and disclosure interaction tests.
- Tab-component state, roving tabindex, arrow navigation, activation, and tab/panel relationship checks.
- Conservative same-origin link validation for empty names, placeholders, missing fragments, confirmed 404/410 destinations, and server-error review signals.
- Desktop, 390px mobile, and 320px reflow viewports.
- Consent-banner detection and dismissal before interaction testing and evidence capture; reject or necessary-only actions are preferred.
- Contextual component screenshots for confirmed failures, with the affected element outlined inside its navigation, form, tablist, card, section, or other component boundary.
- Full-page screenshots only for page-level failures and blockers that have no component locator; a failed component capture never falls back to misleading full-page evidence.
- Lightweight relative screenshot links in `Accessibility Report` and `Image Inventory`; images are not embedded in the workbook.
- Graceful cancellation that writes and validates partial JSON and XLSX output.
- URL, XLSX, CSV, TXT, and JSON page-list inputs.
- One row for the same reusable component implementation, rendered name, and root cause across affected pages; generic unnamed controls also require the same rendered location, and page-specific findings remain separate.
- Embedded instructions, command, skill, rules, MCP server, workbook template, validation, CI checks, and generated marketplace payloads for Claude and GitHub Copilot.

## Requirements

- Node.js 22 or later.
- npm.
- A Playwright-supported Chromium installation. If none is present, the plugin installs headless Playwright Chromium once after audit confirmation unless automatic installation is disabled.
- Microsoft Excel or another OOXML-compatible reader for the generated workbook.

No screen-reader package or operating-system accessibility permission is required.

## Install the plugin dependencies

Clone the plugin into its own directory. Do not install its dependencies inside a repository being audited.

```sh
git clone https://github.com/carla-goncalves_radancy/accessibility-audit-plugin.git accessibility-audit
cd accessibility-audit
npm ci
npm run build
```

Installing Chromium during development is optional but avoids the first-run download:

```sh
npx playwright install chromium
```

The `dist/` directory is produced by `npm run build` and is intentionally not committed.

For complete platform-specific setup, activation, verification, updating, uninstalling, and troubleshooting steps, use [Installation](docs/installation.md). The sections below are the short local-development paths.

## Cursor installation

For local testing on macOS or Linux, Cursor discovers plugins under its local plugin directory. Symlink the built repository and reload Cursor:

```sh
PLUGIN_DIR="$(pwd -P)"
mkdir -p ~/.cursor/plugins/local
ln -sfn "$PLUGIN_DIR" ~/.cursor/plugins/local/accessibility-audit
```

Then run `Developer: Reload Window`, open **Customize**, and confirm that `accessibility-audit` exposes its command, skill, rule, and MCP server.

On Windows PowerShell, clone directly into Cursor's local plugin directory:

```powershell
$Destination = Join-Path $env:USERPROFILE ".cursor\plugins\local\accessibility-audit"
New-Item -ItemType Directory -Force (Split-Path $Destination) | Out-Null
git clone https://github.com/carla-goncalves_radancy/accessibility-audit-plugin.git $Destination
Set-Location $Destination
npm ci
npx playwright install chromium
npm run build
```

After an installation is updated, run `npm ci`, `npm run build`, and reload Cursor.

Cursor can also load the root `mcp.json` when the repository is configured as a plugin. The manifest is [.cursor-plugin/plugin.json](.cursor-plugin/plugin.json).

Cursor Marketplace submission requires a public Git repository. A private repository can instead be used for local development or an organisation’s private team marketplace. See [Installation](docs/installation.md#3a-install-in-cursor) and the [Cursor plugin reference](https://cursor.com/docs/reference/plugins).

## Claude Code installation

Start Claude Code in the unrelated project while loading the separate built checkout:

```sh
cd /path/to/project-being-audited
claude --plugin-dir /path/to/accessibility-audit
```

The Claude plugin manifest is [.claude-plugin/plugin.json](.claude-plugin/plugin.json), and its MCP definition is [.claude-mcp.json](.claude-mcp.json).

For a persistent local installation, add the built checkout as a Claude marketplace and install the plugin:

```text
/plugin marketplace add /path/to/accessibility-audit
/plugin install accessibility-audit@accessibility-audit-marketplace
/reload-plugins
```

Remote private-marketplace publication is a separate release workflow: the user needs repository access and the published snapshot must include runnable build output. See [Installation](docs/installation.md#3b-install-in-claude-code) and the [Claude Code plugin marketplace documentation](https://code.claude.com/docs/en/plugin-marketplaces).

## GitHub Copilot installation

The repository generates separate, marketplace-ready payloads for GitHub Copilot CLI and GitHub Copilot in VS Code. These payloads include compiled code, bundled production dependencies, skills, MCP configuration, and an isolated runtime launcher:

```sh
npm ci
npm run build:marketplace
npm run validate:marketplace
npm run test:marketplace
```

For local Copilot CLI verification, install the generated CLI payload directly:

```sh
copilot plugin install ./marketplace/rai-ops-plugin-marketplace/accessibility-audit/copilot-cli
copilot plugin list
```

For team distribution, use the staged payload and catalog fragments documented in [Marketplace submission](docs/marketplace-submission.md). No marketplace repository is modified by the build command.

## Codex installation

The Codex manifest is [.codex-plugin/plugin.json](.codex-plugin/plugin.json), and the MCP server is declared in [.mcp.json](.mcp.json). Register the separate built checkout as a local marketplace, install it, and start a new session:

```sh
codex plugin marketplace add /path/to/accessibility-audit
codex plugin add accessibility-audit@accessibility-audit-marketplace
codex plugin list
```

In Codex CLI, enter `/plugins` to open the plugin browser. See [Installation](docs/installation.md#3c-install-in-codex) for activation, updating, and troubleshooting.

The Codex IDE extension does not currently support plugins. Use Codex CLI or another supported Codex/ChatGPT plugin surface. See the [official OpenAI plugin documentation](https://developers.openai.com/codex/plugins).

## Run an audit in Cursor, Claude, or Copilot

Use the bundled command:

```text
/accessibility-audit https://preview.example.test/
```

Multiple selected pages:

```text
/accessibility-audit https://preview.example.test/ https://preview.example.test/jobs https://preview.example.test/contact
```

A complete page-list file:

```text
/accessibility-audit /absolute/path/to/pages.xlsx
```

The confirmation form shows the supplied pages or input file and asks for the landing-page QA URL and auditor. `Automated` is the editable auditor default. The landing page defaults to the first resolved URL. If the client does not support MCP forms, the tool returns `confirmation-required`; the agent confirms the same values in chat and retries once.

The plugin tests only the URLs provided. It does not crawl a site or infer missing pages. To audit a complete site, provide a complete canonical URL list in XLSX, CSV, TXT, or JSON form.

## Run from a terminal

Direct invocation:

```sh
node dist/cli.js https://preview.example.test/
```

Explicit audit command with selected options:

```sh
node dist/cli.js audit \
  https://preview.example.test/ \
  https://preview.example.test/jobs \
  --auditor "Auditor Name" \
  --landing-page https://preview.example.test/ \
  --output "accessibility-audit-results" \
  --allow-host preview.example.test \
  --staging-only \
  --max-links 200
```

Page-list input:

```sh
node dist/cli.js audit pages.xlsx \
  --auditor "Auditor Name" \
  --output "accessibility-audit-results" \
  --staging-only
```

Interactive execution prints the targets, asks for the auditor and landing-page QA URL, and asks for start confirmation. `--yes` accepts supplied/default values and starts without prompts.

Progress is written to stderr. The final structured result is written to stdout.

### Stop an audit safely

- In Cursor, Claude, Codex, or Copilot, press the client’s **Stop** control.
- In a terminal, press `Ctrl+C` once.

The plugin closes active Chromium work, retains completed evidence, writes `audit-results.json` and `Accessibility_Audit_Report.xlsx`, validates the partial workbook, packages its files, and returns `status: "cancelled"`. Pressing `Ctrl+C` a second time exits immediately and can prevent report completion.

## Inputs

Supported inputs are:

- One or more explicit HTTP(S) URLs.
- XLSX workbooks. Columns named `QA page`, `Staging URL`, `URL`, or `Page URL` are preferred; otherwise HTTP(S) cells are scanned.
- CSV files containing URLs.
- TXT files containing URLs, normally one per line.
- JSON arrays or objects containing URL strings.

Use `allowedHosts` or repeated `--allow-host` flags to constrain navigation. Enable `stagingOnly` only when every supplied target is a staging, QA, preview, test, or local host.

## Output

The default output directory is `Accessibility Audit Results` under the user’s home directory. A custom `outputDir` can be supplied.

Generated files:

- `Accessibility_Audit_Report.xlsx` — validated 32-column accessibility workbook.
- `audit-results.json` — complete evidence, classifications, requested/completed/skipped pages, and guided checks.
- `screenshots/*.png` — full-page screenshots only for confirmed page-level failures or blockers without a component locator.
- `screenshots/elements/*.png` — confirmed-failure component screenshots when the element is visible and stable; the affected element is outlined within surrounding component context.
- `<output-directory>.zip` — portable copy of the workbook, JSON, and linked screenshot tree, written beside the output directory.

Workbook worksheets:

- `Accessibility Overview` — the single landing-page QA URL, scope, auditor, methods, totals, limitations, and outstanding guided checks.
- `Accessibility Report` — one row per reusable component/root cause across affected pages; page-specific findings remain separate. Summary names the rendered component. Issue states the component, page location, affected Desktop/Mobile viewport, accessibility problem, user impact, and technical locator. All generated rows start as `Fail`, use an operational Assignment, and initialize Estimate to `0`.
- `Page Inventroy` — requested/final URL, HTTP status, page title, viewport, consent-handling result, and runtime errors.
- `Image Inventory` — finding, page, viewport, human-readable component, location, selector, evidence type, screenshot filename, and relative link to the PNG.
- `Lookup WCAG 2.2` — hidden lookup data used by report formulas.

The report contains no screen-reader worksheet or screen-reader execution result.

## Finding confidence and false-positive controls

The report keeps these categories separate:

- `confirmed` — deterministic reproduced evidence, such as a WCAG-tagged axe violation, missing label, broken ARIA relationship, missing fragment, or two-source 404/410 response.
- `review` — a signal requiring human judgment, such as target-size exceptions, text-spacing overflow, placeholder links, a 5xx response, linked-image wording, or ambiguous component behavior.
- `blocker` — the requested page could not be tested.
- `manual` — procedures automation cannot prove.

Link validation deliberately avoids broad crawling and destructive requests:

- Only rendered same-origin links are network-checked.
- External links, downloads, non-HTTP protocols, and logout/delete/remove/unsubscribe paths are not requested.
- HTTP 404/410 is confirmed only when both the authenticated Playwright request context and an in-page browser fetch return the same status.
- HTTP 5xx and placeholder destinations remain review items.
- Empty link names include text, ARIA labels, valid labelled-by text, descendant image alternatives, input values, and titles before being reported.
- Equivalent custom and axe link-name evidence is de-duplicated.
- axe `region` best-practice nodes are summarized as one page-structure review row per page instead of one failed row per DOM node.
- Target-size review signals are reported per rendered control and consolidated only when the same component implementation and root cause recur.
- Focus-obscuration checks sample the visible centre and four inset corners. A control is reported as confirmed only when unrelated content covers every sampled point; off-screen geometry and one covered point do not create a failure.

Tab checks do not report optional Home/End support as a failure. They separately test orientation-aware arrow navigation, Enter/Space or automatic activation, `aria-selected`, tabindex behavior, `aria-controls`, `tabpanel`, and `aria-labelledby` relationships. Broken references and keyboard-unreachable tabs are confirmed; non-standard but potentially operable authoring patterns remain review items.

## Configuration

Pass `--config audit.config.json`. Command-line values override the file.

```json
{
  "auditor": "Automated",
  "landingPageUrl": "https://preview.example.test/",
  "outputDir": "artifacts/client-audit",
  "allowedHosts": ["preview.example.test"],
  "stagingOnly": true,
  "headless": true,
  "autoInstallBrowser": true,
  "concurrency": 2,
  "timeoutMs": 30000,
  "maxTabStops": 120,
  "maxLinksPerPage": 200,
  "captureScreenshots": true
}
```

Use `--headed` only when debugging. Normal and CI execution should remain headless.

## MCP tools

- `run_accessibility_audit` — recommended one-shot entry point with confirmation, progress, cancellation, report generation, and validation.
- `audit_pages` — lower-level explicit URL entry point.
- `audit_from_file` — lower-level page-list entry point.
- `get_audit_instructions` — returns the embedded generic workflow.
- `validate_accessibility_report` — validates workbook structure, remediation, image evidence, and obsolete-sheet removal.
- `list_guided_manual_checks` — returns procedures automation does not prove.

The server also publishes the `run-accessibility-audit` MCP prompt.

## What the automation does not prove

Automation cannot establish complete WCAG conformance. Manual work remains necessary for:

- Supported screen-reader/browser combinations and dynamic announcements.
- Physical mobile devices, touch gestures, orientation, and drag alternatives.
- Alternative-text meaning, captions, audio descriptions, language changes, and heading/label quality.
- Complete contrast over gradients, images, and every component state.
- Timing, flashing, cognitive consistency, error quality, accessible authentication, and exception analysis.
- Complete keyboard journeys and application-specific workflows not safely submitted by automation.

Use `list_guided_manual_checks`, the workbook Overview, and [docs/manual-verification.md](docs/manual-verification.md) to complete those procedures.

## Security and isolation

- The target repository is read-only. The plugin does not edit source, governance files, agent rules, CI, hooks, manifests, or lockfiles.
- Source-checkout dependencies stay in the plugin directory. Marketplace runtime dependencies and downloaded browsers stay in client-owned plugin data, never in the audited project.
- Output is written only to the configured audit directory.
- Only explicitly supplied URLs are audited.
- Visible consent banners are dismissed before component checks and screenshot capture. The Page Inventory and JSON state whether a banner was found, which action was used, and whether it was dismissed.
- Host allowlists and optional staging-only enforcement are available.
- Browser checks are headless by default.
- No credentials are collected or transmitted by the plugin. Authenticated pages use the browser context available to the launched audit session.
- Screenshots and page content can contain sensitive information; protect and delete report artifacts according to project policy.

See [SECURITY.md](SECURITY.md) for vulnerability reporting and data-handling notes.

## Validate and develop

```sh
npm run lint
npm run typecheck
npm test
npm run build
npm run test:integration
npm run build:marketplace
npm run validate:marketplace
npm run test:marketplace
npm pack --dry-run
```

Validate a generated workbook:

```sh
node dist/cli.js validate accessibility-audit-results/Accessibility_Audit_Report.xlsx
```

The integration suite runs real Chromium, verifies confirmed/review classifications, checks focused screenshot capture and relative evidence links, validates the portable archive, and tests graceful cancellation. Unit tests do not replace real browser or manual assistive-technology verification.

## Troubleshooting

### Plugin or MCP server is not visible

1. Run `npm ci` and `npm run build` in the plugin directory.
2. Confirm `dist/mcp.js` exists.
3. Reload the editor or start a new Claude, Codex, or Copilot session.
4. Confirm the plugin is enabled at the intended user/workspace scope.
5. Review the client’s MCP logs for `accessibility-audit` startup errors.

### Chromium executable is missing

The plugin installs Playwright Chromium automatically when no bundled Chromium, Chrome, or Edge executable is available. If automatic downloads are blocked, run `npx playwright install chromium` in the plugin checkout or configure a supported browser. Pass `--no-auto-install-browser` only when that fallback must be disabled.

### A page was skipped

Check `allowedHosts`, `stagingOnly`, redirects, authentication, and the `skippedUrls` or Page Inventory reason. A skipped or interrupted page is never presented as passed.

### A broken link looks incorrect

Inspect the JSON evidence, response status, final URL, authentication state, and page-specific routing. Only matching 404/410 checks are confirmed; other uncertain states remain review findings.

### Images are missing from Image Inventory

Keep `captureScreenshots` enabled, confirm the output directory is writable, and inspect the JSON evidence path. Screenshots are intentionally generated only for confirmed failures and page blockers. A component whose selector cannot be resolved is left without a screenshot instead of receiving unrelated full-page evidence. Keep the workbook beside its `screenshots` directory or use the generated ZIP so the relative links continue to work.

## Support and contribution

- Installation for Cursor, Claude Code, Codex, and GitHub Copilot: [docs/installation.md](docs/installation.md)
- RAI Ops marketplace packaging and submission: [docs/marketplace-submission.md](docs/marketplace-submission.md)
- Start-to-finish instructions: [docs/user-guide.md](docs/user-guide.md)
- WCAG terminology for non-specialists: [docs/wcag-basics.md](docs/wcag-basics.md)
- Usage and troubleshooting: [SUPPORT.md](SUPPORT.md)
- Security reports: [SECURITY.md](SECURITY.md)
- Contribution and verification requirements: [CONTRIBUTING.md](CONTRIBUTING.md)
- Release history: [CHANGELOG.md](CHANGELOG.md)
- Detailed test matrix: [docs/testing-matrix.md](docs/testing-matrix.md)
- Workbook behavior: [docs/reporting.md](docs/reporting.md)
- Guided checks after automation: [docs/manual-verification.md](docs/manual-verification.md)

## License

MIT. See [LICENSE](LICENSE).
